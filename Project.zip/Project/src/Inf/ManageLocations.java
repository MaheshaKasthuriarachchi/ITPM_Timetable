
package Inf;

import codes.DBconect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;


public class ManageLocations extends javax.swing.JFrame {

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    
    public ManageLocations() {
        initComponents();
        conn = DBconect.connect();
        tableload();
        
    }

    public void tableload(){
        
        try {
            String sql = "SELECT id AS ID,bname AS BuildingName,rname AS RoomName,rType AS RoomType,capacity AS Capacity FROM location ";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            view.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    public void tabledata(){
        
        int r = view.getSelectedRow();
        
        String id = view.getValueAt(r, 0).toString();
        String bname = view.getValueAt(r, 1).toString();
        String rname = view.getValueAt(r, 2).toString();
        String rType = view.getValueAt(r, 3).toString();
        String capacity = view.getValueAt(r, 4).toString();
        
        idBox.setText(id);
        BName.setText(bname);
        RName.setText(rname);
        hh.setSelectedItem(rType);
        CName.setText(capacity);
        
    }
    
    
    public void update(){
      
        String id = idBox.getText();
        String buildingName = BName.getText();
        String roomName = RName.getText();
        String roomType = hh.getSelectedItem().toString();
        String capacity = CName.getText();
        
        try {
             String sql = "UPDATE location SET bname'"+buildingName+"', rname'"+roomName+"', rType'"+roomType+"', capacity'"+capacity+"' WHERE id= '"+id+"' ";
             pst = conn.prepareStatement (sql);
             pst.execute();
             JOptionPane.showMessageDialog(null, "updated!");
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "updated");
            
            
        }
        
    }
    
    
    public void clear (){

        idBox.setText("id");
        BName.setText("bname");
        RName.setText("rname");
        hh.setSelectedIndex(0);
        CName.setText("capacity");
}
      
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        view = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        RName = new javax.swing.JTextField();
        BName = new javax.swing.JTextField();
        CName = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        hh = new javax.swing.JComboBox();
        Ibutton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        idBox = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 102, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("Manage locations");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 340, -1));

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        view.setBackground(new java.awt.Color(204, 255, 204));
        view.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        view.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewMouseClicked(evt);
            }
        });
        view.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                viewKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(view);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 440, 220));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 610, 230));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Building Name:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Room Name");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Room Type");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 350, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Capacity");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 440, -1, -1));

        RName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RNameActionPerformed(evt);
            }
        });
        jPanel1.add(RName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 430, 200, 30));
        jPanel1.add(BName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 200, 30));
        jPanel1.add(CName, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 440, 210, 30));

        jButton1.setBackground(new java.awt.Color(0, 255, 204));
        jButton1.setForeground(new java.awt.Color(255, 0, 51));
        jButton1.setText("UPDATE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 80, 110, 30));

        jButton2.setBackground(new java.awt.Color(0, 51, 204));
        jButton2.setText("CLEAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 130, 110, 30));

        jButton3.setBackground(new java.awt.Color(0, 153, 153));
        jButton3.setText("DELET");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, 110, 30));

        hh.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "1 Lecture Hall", "2 Laboratory" }));
        hh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hhActionPerformed(evt);
            }
        });
        jPanel1.add(hh, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 340, 140, 30));

        Ibutton.setBackground(new java.awt.Color(0, 0, 0));
        Ibutton.setForeground(new java.awt.Color(255, 0, 0));
        Ibutton.setText("INSERT");
        Ibutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IbuttonActionPerformed(evt);
            }
        });
        jPanel1.add(Ibutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 250, 110, 30));

        jLabel6.setText("ID");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, -1, 10));

        idBox.setText("ID");
        jPanel1.add(idBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 310, -1, -1));

        jButton4.setBackground(new java.awt.Color(204, 255, 204));
        jButton4.setText("NEXT");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(793, 430, 60, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RNameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
       update();
       tableload();
       
       
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void hhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hhActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hhActionPerformed

    private void IbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IbuttonActionPerformed
        
       String buildingName;
       String roomName;
       String roomType;
       int capacity;
       
       buildingName  = BName.getText();
       roomName = RName.getText();
       roomType = hh.getActionCommand();
       capacity = Integer.parseInt(CName.getText());
       
        try {
           String sql = "INSERT INTO location (bname,rname,rType,capacity) VALUES ('"+buildingName+"','"+roomName+"','"+roomType+"','"+capacity+"') ";
           pst = conn.prepareStatement(sql);
           pst.execute();
           
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            
        }
       
       tableload();
    }//GEN-LAST:event_IbuttonActionPerformed

    private void viewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewMouseClicked
      
        tabledata();
        
    }//GEN-LAST:event_viewMouseClicked

    private void viewKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_viewKeyReleased
        
        tabledata();
        
        
    }//GEN-LAST:event_viewKeyReleased

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       
        int check = JOptionPane.showConfirmDialog(null, "do you want to delet!");
        
        if(check==0){
            String id = idBox.getText();
            
            try {
                String sql = " DELETE FORM location WHERE id='"+id+"'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                
                
                
                       
                        
                        } catch (Exception e) {
            }
        }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        clear ();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         vis v1 = new vis();
        v1.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageLocations.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageLocations.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageLocations.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageLocations.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageLocations().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BName;
    private javax.swing.JTextField CName;
    private javax.swing.JButton Ibutton;
    private javax.swing.JTextField RName;
    private javax.swing.JComboBox hh;
    private javax.swing.JLabel idBox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable view;
    // End of variables declaration//GEN-END:variables
}
